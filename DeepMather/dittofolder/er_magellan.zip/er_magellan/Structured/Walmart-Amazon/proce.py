import hashlib
import json
from pathlib import Path
import ollama
import re
import os
from groq import Groq

# Init Groq Client
client = Groq(api_key="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")

# Cache directory
CACHE_DIR = Path("llm_cache_summ")
CACHE_DIR.mkdir(exist_ok=True)


def get_cache_path(entity):
    entity_hash = hashlib.md5(entity.encode()).hexdigest()
    return CACHE_DIR / f"{entity_hash}.json"



def build_prompt(s1, s2,label, max_tokens):
   
        if label=="1":
            return   f"""
    You are a product record normalization assistant. Your task is to normalize and canonicalize **two product records** for use in entity matching.

    ---

    ### INSTRUCTIONS:

    1. **Do NOT remove any meaningful information from the `title` field**.  
    Instead:
    - **Align both titles** by resolving formatting inconsistencies, such as:
        - Dash vs. space
        - Word order if semantically identical
        - Typos, extra repeated words, inconsistent punctuation
    - Do not apply title casing — preserve original casing and structure
    - Keep all descriptive information like color, size, specs, compatibility, etc.

    2. **manufacturer / brand**:  
    - Standardize known aliases (e.g., "Hewlett Packard" → "HP")  
    - Remove suffixes like "Inc.", "Ltd."  
    - Preserve original casing

    3. **modelno**:   
    - Remove packaging codes like "#B1H" unless needed to distinguish the product

    4. **price**:  
    - Remove `$` if present  
    - Convert to float with two decimal places (e.g., `49.87`)  

    ---

    ### PRESERVATION POLICY:
    - **Do not shorten or strip details** in `title`, `manufacturer`, `brand`, or `modelno`
    - Align formats and clean inconsistencies **only if** the records refer to the same product



    ### OUTPUT FORMAT:
    Return a single line, starting with the word `Output:`, where the two transformed records are separated by exactly **one literal tab character** (`\t`), and fields are structured as:
    Output: COL title VAL [title_1] COL manufacturer VAL [manufacturer_1] COL brand VAL [brand_1] COL modelno VAL [modelno_1] COL price VAL [price_1]\tCOL title VAL [title_2] COL manufacturer VAL [manufacturer_2] COL brand VAL [brand_2] COL modelno VAL [modelno_2] COL price VAL [price_2]

    - ✅ Use exactly one literal tab character — not multiple tabs, not "\\t".
    - ❌ Never insert a tab between COL and VAL or inside values.
    - ❌ Never use multi-line output. Keep everything on a **single line**.

    ## CRITICAL CONSTRAINTS:
    - Focus on core product identity, remove packaging and platform details
    - NEVER add trailing tags at the end of records
    - Maintain proper spacing throughout
    - Extract essential product details while removing technical specifications

    ------------------------

    Input: {s1}\t{s2}

    PROVIDE ONLY THE CLEAN OUTPUTS SEPARATED BY A TAB CHARACTER, NOTHING ELSE. DO NOT PROVIDE EXTRA EXPLANATIONS.
    Process each record pair according to these rules, maintaining structural integrity while highlighting key differences that affect matching accuracy. Your output should ONLY be the transformed records, with NO explanations.

    """

        else:
            return f"""
    You are a product record normalization assistant. Your task is to **lightly clean and format two product records that DO NOT refer to the same item**. These products are **different**, so do not align or merge their information. Just remove inconsistencies.

    ---

    ### LIGHT FORMATTING RULES:

    1. **Preserve all semantic differences. Do not try to make the records appear similar.**

    2. **Title field:**
    - Remove **redundant or repeated words**, e.g., "printer printer"
    - Fix basic formatting issues (extra dashes, double spaces, trailing punctuation)
    - Do **not** rephrase or reorder words to make the records appear aligned
    - Keep all descriptive information — **do not shorten or standardize** based on assumptions
    

    3. **Brand, Manufacturer, Model Number:**
    - Preserve as-is unless there are obvious typos or repeated tokens
    - Keep original casing
    - Standardize known aliases (e.g., "Hewlett Packard" → "HP")

    4. **Price:**
    - Remove any `$` signs
    - Convert to float with two decimal places (e.g., `10.0` → `10.00`)
    - Leave blank if price is missing

    ---


    ### OUTPUT FORMAT:
    Return a single line, starting with the word `Output:`, where the two transformed records are separated by exactly **one literal tab character** (`\t`), and fields are structured as:
    Output: COL title VAL [title_1] COL manufacturer VAL [manufacturer_1] COL brand VAL [brand_1] COL modelno VAL [modelno_1] COL price VAL [price_1]\tCOL title VAL [title_2] COL manufacturer VAL [manufacturer_2] COL brand VAL [brand_2] COL modelno VAL [modelno_2] COL price VAL [price_2]

    - ✅ Use exactly one literal tab character — not multiple tabs, not "\\t".
    - ❌ Never insert a tab between COL and VAL or inside values.
    - ❌ Never use multi-line output. Keep everything on a **single line**.


    Input: {s1}\t{s2}

    PROVIDE ONLY THE CLEAN OUTPUTS SEPARATED BY A TAB CHARACTER, NOTHING ELSE. DO NOT PROVIDE EXTRA EXPLANATIONS.
    Process each record pair according to these rules, maintaining structural integrity while highlighting key differences that affect matching accuracy. Your output should ONLY be the transformed records, with NO explanations.

        """ 
    

    
def extract_output_line_deepseek(text):
    """
    Extract the line that starts with 'Output:' and contains exactly one tab.
    If no valid line is found, raise an error.
    """
      
    for line in text.splitlines():
        if line.strip().startswith("Output:"):
            line = line.strip()

            # Attempt to fix if there's no real tab but just space between two records
            match = re.search(r'(COL .+?VAL .+?)( COL )', line)
            if match and line.count('\t') == 0:
                # Insert real tab between the two records
                parts = line[7:].split("COL ", 1)
                if len(parts) == 2:
                    fixed = f"Output: COL {parts[0].strip()}\tCOL {parts[1].strip()}"
                    return fixed

            # Otherwise, return as-is if it already has one real tab
            if line.count('\t') == 1:
                return line

    raise ValueError("❌ Could not find or fix a valid 'Output:' line with a tab in the model response.")

def clean_and_validate(result, s1, s2):
    
    if result.count('\t') == 0:
        # Try splitting on 'COL name VAL' to find the second record
        split_match = re.split(r'(COL name VAL )', result, maxsplit=2)
        if len(split_match) >= 3:
            # Reconstruct: part1 + tab + part2
            part1 = split_match[0].strip()
            part2 = split_match[1] + split_match[2].strip()
            result = f"{part1}\t{part2}"
        else:
            # As a fallback, try replacing long space block (4+ spaces) with tab
            if re.search(r'\s{4,}', result):
                result = re.sub(r'\s{4,}', '\t', result, count=1)
        
    result = result.replace('\\t', '\t').replace('\n', '\t').replace('\r', '\t')
    result = re.sub(r'\t+', '\t', result).strip()

    while '\t\t' in result:
        result = result.replace('\t\t', '\t')

    if result.count('\t') != 1:
        raise ValueError("❌ Output must contain exactly one real tab character. Found {result.count('\t')}: {repr(result)}")

    if '\\t' in result or '\n' in result or '\r' in result:
        raise ValueError(f"❌ Output contains invalid characters: {repr(result)}")

    parts = [p.strip() for p in result.split('\t') if p.strip()]
    if len(parts) != 2:
        raise ValueError(f"❌ Output split does not yield exactly 2 records: {repr(result)}")

    return result


def summarize_pair(s1, s2,label, max_tokens=128, max_attempts=5):
    
    # if label.strip() != "1":
    #     print("Skipping prompt: label is", label)
    #     return f"{s1}\t{s2}"
    
    cache_key = f"{s1}||{s2}"
    cache_path = get_cache_path(cache_key)

    if cache_path.exists():
        try:
            with open(cache_path, 'r') as f:
                cached_data = json.load(f)
                return cached_data['response']
        except:
            print(f"⚠️ Invalid cache file {cache_path}, will regenerate...")

    prompt = build_prompt(s1, s2,label, max_tokens)

    last_error = None
    for attempt in range(1, max_attempts + 1):
        try:
            response = ollama.chat(
                model="mistral-nemo:latest",
                options={"temperature": 0.0, "num_predict": 2000},
                 messages=[
                    {
                        "role": "system",
                        "content": (
                            "You are entity matcher for the ditto. Do not explain. "
                            "Do not describe anything. Do not say 'Output:' or '<think>'. "
                            "Do not provide reasoning, steps, formatting explanation, or notes. "
                            "Return EXACTLY one line with TWO transformed records separated by ONE real tab character. PRESERVE ORIGINAL CASE. Do NOT change to title case. Do not capitalize words unless already capitalized. "
                            "No headings. No thoughts. No multiple lines. No Markdown. No JSON. Only raw string output. "
                            "If you violate this, your output will be rejected."
                        )
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ]
            )

            result = response["message"]["content"].strip()
            # result = result.lower()
            # print("raw output:",result)
            # fresult = extract_output_line_deepseek(result)
            print("reslut **",result)
            
            result = clean_and_validate(result, s1, s2)

            with open(cache_path, 'w') as f:
                json.dump({"response": result}, f)

            print(f"✓ Valid output on attempt {attempt}")
            return result

        except Exception as e:
            print(f"❌ Attempt {attempt} failed: {e}")
            last_error = e

    print(f"❌ All {max_attempts} attempts failed. Returning original input.")
    return f"{s1}\t{s2}"


def preprocess_file(input_path):
    print(f"\n🔧 Preprocessing: {input_path}")
    input_path = Path(input_path)
    output_path = input_path.with_name(input_path.stem + "_enrich.txt")

    cache = {}

    with open(input_path, "r", encoding="utf-8") as fin, open(output_path, "w", encoding="utf-8") as fout:
        for i, line in enumerate(fin, 1):
            try:
                parts = line.strip().split('\t')
                if len(parts) != 3:
                    raise ValueError(f"Expected 3 fields, got {len(parts)}")

                s1, s2, label = parts
                cache_key = f"{s1}||{s2}"
            
                if cache_key not in cache:
                    cache[cache_key] = summarize_pair(s1, s2,label)
                    print(f"✓ Line {i} summarized.")

                transformed = cache[cache_key]
                formatted = f"{transformed}\t{label}\n"

                if formatted.strip().count('\t') != 2:
                    raise ValueError(f"❌ Final formatted line is malformed: {repr(formatted)}")

                fout.write(formatted)

            except Exception as e:
                print(f"❌ Skipping line {i} due to error: {e}")

    print(f"✅ Saved enriched file to: {output_path}")


if __name__ == "__main__":
    filenames = [ "test.txt","valid.txt","train.txt"]

    for fname in filenames:
        path = Path(fname)
        if not path.exists():
            print(f"⚠️ File not found: {fname}")
            continue

        preprocess_file(str(path))

