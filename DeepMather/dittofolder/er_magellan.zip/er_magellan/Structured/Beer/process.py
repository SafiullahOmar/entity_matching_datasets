import hashlib
import json
from pathlib import Path
import ollama
import re
import os
from groq import Groq

# Init Groq Client
client = Groq(api_key="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")

# Cache directory
CACHE_DIR = Path("llm_cache_summ")
CACHE_DIR.mkdir(exist_ok=True)


def get_cache_path(entity):
    entity_hash = hashlib.md5(entity.encode()).hexdigest()
    return CACHE_DIR / f"{entity_hash}.json"



def build_prompt(s1, s2,label, max_tokens):
    return f"""
You are a record normalizer optimizing for BERT-based similarity matching. Your job is to transform raw records into a standardized format that maximizes match accuracy.

## CORE OBJECTIVES:
1. Maintain consistent COL/VAL structure
2. Add strategic PRODUCT tags to highlight distinctive elements
3. Add NUM tags to numeric values
4. Normalize style descriptions
5. Preserve 0/1 pair matching indicators

## TRANSFORMATION RULES:

### Structure and Formatting:
- Keep the exact COL/VAL structure with ONE tab character between record pairs
- Ensure no field merging (e.g., "COL Beer_NamePRODUCT" should be "COL Beer_Name PRODUCT")
- Never add trailing tags at record ends
- Ensure correct spacing around tags

### PRODUCT Tag Application:
- Add PRODUCT tags ONLY to distinctive product entity elements:
* Unique product entity name components
* Distinctive pair attributes
- Maximum of ONE PRODUCT tag per field value
- Apply PRODUCT tags consistently between matching pairs
- Place PRODUCT tags BEFORE the VAL tag, never after

### Style Normalization:
- Convert "American Amber / Red Ale" to "American / Red"
- For empty style fields, use "COL Style VAL" (no content)
- Be consistent in style abbreviations

### Number Formatting:
- Use exactly ONE NUM tag: "VAL NUM 5.40 %" (with space before %)
- For missing ABV values, use "VAL NUM -"
- Format all percentages consistently

### Match-Sensitive Transformations:
- Preserve distinctive terms that differentiate similar entity
- Apply consistent transformations to both records in a pair
- When entity pairs have a similarity indicator of 1, ensure matching fields have similar tagging

### Canonicalization Rule

- Strip non-essential tags and metadata from names or titles such as (Deluxe Version), [Explicit], (Win/Mac), Promo, EP, Inc., LLC, etc.
  Example: "Immersion Spanish Deluxe 2.0 (Win/Mac) [Jewel Case]" → "Immersion Spanish Deluxe 2.0"
- Standardize text formatting by applying Title Case, normalizing symbols (e.g., /, -, feat.), removing extra punctuation, and trimming spaces.
  Example: "true colors (feat. nicki minaj) [explicit]" → "True Colors feat. Nicki Minaj"
---

CRITICAL CONSTRAINTS
- NEVER use double NUM or PRODUCT tags.
- NEVER merge COL and tag fields.
- NEVER add tags after field values.
- NEVER add trailing tags at the end of records.
- Only use tags specified in the rules.
- Maintain proper spacing and structure throughout.
- Output only the transformed records on a single line, separated by a real tab character, and nothing else.

---
        
## OUTPUT FORMAT:
Return a single line, starting with the word Output:, where two fully transformed records are separated by exactly one literal tab character (`\t`). Do not place tabs anywhere else.

Correct Format:
Output: COL Beer_Name  VAL [Beer_Name_1]; COL Brew_Factory_Name VAL [Brew_Factory_Name_1]; COL Style VAL NUM [Style_1]; COL ABV VAL NUM [ABV_1];    COL Beer_Name  VAL [Beer_Name_2]; COL Brew_Factory_Name VAL [Brew_Factory_Name_2]; COL Style VAL NUM [Style_2]; COL ABV VAL NUM [ABV_2];


✅ Use exactly one literal tab character — not multiple tabs, not "\\t" string.
❌ Never insert a tab between COL and VAL or inside values.
❌ Never output on multiple lines.



----------------
## EXAMPLES --only for context ----:
### Original:
COL Beer_Name VAL Hoppy Face Amber Ale COL Brew_Factory_Name VAL Hoppy Brewing Co. COL Style VAL American Amber / Red Ale COL ABV VAL 6.10 % COL Beer_Name VAL 2nd Story Hoppy New Year Amber Ale COL Brew_Factory_Name VAL 2nd Story Brewing Company COL Style VAL Amber Ale COL ABV VAL 5.70 %
### Transformed:
COL Beer_Name PRODUCT VAL Hoppy Face Amber Ale COL Brew_Factory_Name VAL Brewing Co. COL Style PRODUCT VAL American / Red COL ABV VAL NUM 6.10 % COL Beer_Name VAL 2nd Story Hoppy New Year PRODUCT VAL Amber Ale COL Brew_Factory_Name VAL Brewing Company COL Style VAL Amber Ale COL ABV VAL NUM 5.70 %

### Original:
COL Beer_Name VAL Buckleys Original Ale COL Brew_Factory_Name VAL Buckley's Beers COL Style VAL American Amber / Red Ale COL ABV VAL 4.50 % COL Beer_Name VAL Buckleys Original Ale COL Brew_Factory_Name VAL Yarra Flats Brewery COL Style VAL English Pale Ale COL ABV VAL 4.90 %

### Transformed:
COL Beer_Name PRODUCT VAL Buckleys Original Ale COL Brew_Factory_Name VAL Buckley's Beers COL Style PRODUCT VAL American / Red COL ABV VAL NUM 4.50 % COL Beer_Name PRODUCT VAL Buckleys Original Ale COL Brew_Factory_Name PRODUCT VAL Yarra Flats Brewery COL Style PRODUCT VAL English Pale Ale COL ABV VAL NUM 4.90 %
---------------

## CRITICAL CONSTRAINTS:
- NEVER use double NUM tags
- NEVER merge COL and tag fields
- NEVER add tags after field values
- NEVER add trailing tags at the end of records
- Maintain proper spacing throughout
- Only use tags specified in the rules

------------------------

Input: {s1}\t{s2}

PROVIDE ONLY THE CLEAN OUTPUTS SEPARATED BY A TAB CHARACTER, NOTHING ELSE. DO NOT PROVIDE EXTRA EXPLANATIONS.
Process each record pair according to these rules, maintaining structural integrity while highlighting key differences that affect matching accuracy. Your output should ONLY be the transformed records, with NO explanations.

"""



    
def extract_output_line_deepseek(text):
    """
    Extract the line that starts with 'Output:' and contains exactly one tab.
    If no valid line is found, raise an error.
    """
      
    for line in text.splitlines():
        if line.strip().startswith("Output:"):
            line = line.strip()

            # Attempt to fix if there's no real tab but just space between two records
            match = re.search(r'(COL .+?VAL .+?)( COL )', line)
            if match and line.count('\t') == 0:
                # Insert real tab between the two records
                parts = line[7:].split("COL ", 1)
                if len(parts) == 2:
                    fixed = f"Output: COL {parts[0].strip()}\tCOL {parts[1].strip()}"
                    return fixed

            # Otherwise, return as-is if it already has one real tab
            if line.count('\t') == 1:
                return line

    raise ValueError("❌ Could not find or fix a valid 'Output:' line with a tab in the model response.")

def clean_and_validate(result, s1, s2):
    
    if result.count('\t') == 0:
        # Try splitting on 'COL name VAL' to find the second record
        split_match = re.split(r'(COL name VAL )', result, maxsplit=2)
        if len(split_match) >= 3:
            # Reconstruct: part1 + tab + part2
            part1 = split_match[0].strip()
            part2 = split_match[1] + split_match[2].strip()
            result = f"{part1}\t{part2}"
        else:
            # As a fallback, try replacing long space block (4+ spaces) with tab
            if re.search(r'\s{4,}', result):
                result = re.sub(r'\s{4,}', '\t', result, count=1)
        
    result = result.replace('\\t', '\t').replace('\n', '\t').replace('\r', '\t')
    result = re.sub(r'\t+', '\t', result).strip()

    while '\t\t' in result:
        result = result.replace('\t\t', '\t')

    if result.count('\t') != 1:
        raise ValueError("❌ Output must contain exactly one real tab character. Found {result.count('\t')}: {repr(result)}")

    if '\\t' in result or '\n' in result or '\r' in result:
        raise ValueError(f"❌ Output contains invalid characters: {repr(result)}")

    parts = [p.strip() for p in result.split('\t') if p.strip()]
    if len(parts) != 2:
        raise ValueError(f"❌ Output split does not yield exactly 2 records: {repr(result)}")

    return result


def summarize_pair(s1, s2,label, max_tokens=128, max_attempts=5):
    
    # if label.strip() != "1":
    #     print("Skipping prompt: label is", label)
    #     return f"{s1}\t{s2}"
    
    cache_key = f"{s1}||{s2}"
    cache_path = get_cache_path(cache_key)

    if cache_path.exists():
        try:
            with open(cache_path, 'r') as f:
                cached_data = json.load(f)
                return cached_data['response']
        except:
            print(f"⚠️ Invalid cache file {cache_path}, will regenerate...")

    prompt = build_prompt(s1, s2,label, max_tokens)

    last_error = None
    for attempt in range(1, max_attempts + 1):
        try:
            response = ollama.chat(
                model="mistral-nemo:latest",
                options={"temperature": 0.0, "num_predict": 2000},
                 messages=[
                    {
                        "role": "system",
                        "content": (
                            "You are entity matcher for the ditto. Do not explain. "
                            "Do not describe anything. Do not say 'Output:' or '<think>'. "
                            "Do not provide reasoning, steps, formatting explanation, or notes. "
                            "Return EXACTLY one line with TWO transformed records separated by ONE real tab character. PRESERVE ORIGINAL CASE. Do NOT change to title case. Do not capitalize words unless already capitalized. "
                            "No headings. No thoughts. No multiple lines. No Markdown. No JSON. Only raw string output. "
                            "If you violate this, your output will be rejected."
                        )
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ]
            )

            result = response["message"]["content"].strip()
            # result = result.lower()
            # print("raw output:",result)
            # fresult = extract_output_line_deepseek(result)
            print("reslut **",result)
            
            result = clean_and_validate(result, s1, s2)

            with open(cache_path, 'w') as f:
                json.dump({"response": result}, f)

            print(f"✓ Valid output on attempt {attempt}")
            return result

        except Exception as e:
            print(f"❌ Attempt {attempt} failed: {e}")
            last_error = e

    print(f"❌ All {max_attempts} attempts failed. Returning original input.")
    return f"{s1}\t{s2}"


def preprocess_file(input_path):
    print(f"\n🔧 Preprocessing: {input_path}")
    input_path = Path(input_path)
    output_path = input_path.with_name(input_path.stem + "_enrich.txt")

    cache = {}

    with open(input_path, "r", encoding="utf-8") as fin, open(output_path, "w", encoding="utf-8") as fout:
        for i, line in enumerate(fin, 1):
            try:
                parts = line.strip().split('\t')
                if len(parts) != 3:
                    raise ValueError(f"Expected 3 fields, got {len(parts)}")

                s1, s2, label = parts
                cache_key = f"{s1}||{s2}"
            
                if cache_key not in cache:
                    cache[cache_key] = summarize_pair(s1, s2,label)
                    print(f"✓ Line {i} summarized.")

                transformed = cache[cache_key]
                formatted = f"{transformed}\t{label}\n"

                if formatted.strip().count('\t') != 2:
                    raise ValueError(f"❌ Final formatted line is malformed: {repr(formatted)}")

                fout.write(formatted)

            except Exception as e:
                print(f"❌ Skipping line {i} due to error: {e}")

    print(f"✅ Saved enriched file to: {output_path}")


if __name__ == "__main__":
    filenames = [ "test.txt","valid.txt","train.txt"]

    for fname in filenames:
        path = Path(fname)
        if not path.exists():
            print(f"⚠️ File not found: {fname}")
            continue

        preprocess_file(str(path))

