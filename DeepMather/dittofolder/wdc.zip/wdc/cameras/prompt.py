import hashlib
import json
from pathlib import Path
import ollama
import re
import os
from groq import Groq

# Init Groq Client
client = Groq(api_key="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")

# Cache directory
CACHE_DIR = Path("llm_cache_summ")
CACHE_DIR.mkdir(exist_ok=True)


def get_cache_path(entity):
    entity_hash = hashlib.md5(entity.encode()).hexdigest()
    return CACHE_DIR / f"{entity_hash}.json"



def build_prompt(s1, s2,label, max_tokens):
    return f"""
You are a record normalizer optimizing for BERT-based similarity matching.
Your job is to transform raw CAMERA-CATEGORY records into a standardised format
that maximises match accuracy while preserving key differentiators.

────────────────────────────────────────────────────────────────────────
CORE OBJECTIVES
1. Preserve the exact COL/VAL schema for every field.
2. Normalise wording variants and style descriptors common to photo/video gear.
3. Canonicalise titles by stripping store-front fluff, bundle language, legal
   suffixes, redundant colour adjectives, etc.
4. Keep distinctive attributes intact (focal length, aperture, sensor size,
   model code, capacity, colour, tripod-series, battery SKU).
5. Respect the 0/1 pair-matching indicator—apply identical transformations to
   matching pairs, but keep true differences for non-matches.

────────────────────────────────────────────────────────────────────────
TRANSFORMATION RULES

■ Structure & formatting  
– Keep the literal tokens `COL` and `VAL`; never merge them.  
– Separate the two transformed records with **one literal tab** (`\t`) only.  
– End each record with a semicolon `;`.  
– Do *not* add extra spaces, tabs, or line breaks.

■ Canonicalisation  
– Remove marketing fluff: “Bundle”, “Starter Kit”, “Accessory Set”, “Official”,  
  “Pro Pack”, “Edition”, “Promo”, “Special Offer”, “™”, “®”, “Inc.”, “LLC”, etc.  
– Collapse repeated spaces, normalise mixed slashes/dashes, apply Title Case
  where sensible.  
– If multiple product names appear (pipes `|`, “/” lists, commas), keep ONLY the
  first meaningful camera-related string.  
– Preserve model/part numbers exactly (e.g., *DMC-GH3K*, *LP-E4N*, *MHXPRO-3W*).  
– Standardise common camera variants:  
  • Focal range: `24-70mm`, `24-70 mm`, `24-70MM` → `24-70 mm`  
  • Aperture: `f2.8`, `F/2.8`, `f 2 . 8` → `f/2.8`  
  • Sensor references: `APS-C`, `Aps C`, `APS-C Sensor` → `APS-C`  
  • Resolution: `1080p`, `Full HD 1080 P`, `1080 P` → `1080 p`  
  • “Inch” sizes: `3.50"`, `3.5-in`, `3 . 5"` → `3.5"`  
  • GoPro generational names: `HERO3+`, `Hero 3 Plus`, `HERO 3+` → `Hero 3 Plus`  
  • Tripod tiering: `3-Way`, `3 Way`, `Three Way` → `3-Way`  
  • “Body Only” / “Kit”: keep phrase but ensure casing (`Body Only`, `Kit`).  

■ Style field normalisation  
– If a Style-type field exists (e.g., “Mount Type”), keep only essential mount
  terms: “Tripod”, “Ball Head”, “Fluid Head”, “Arca-Swiss”, “GoPro Mount”, etc.  
– If the style field is empty: output `COL Style VAL` (blank).

■ Match-sensitive handling  
– If pair indicator = **1**, outputs of both sides must be textually identical
  after normalisation.  
– If indicator = **0**, preserve genuine attribute differences (focal length,
  aperture, capacity, colour, kit vs body-only, head type, etc.).

---
       
## OUTPUT FORMAT:
Return a single line, starting with the word Output:, where two fully transformed records are separated by exactly one literal tab character (`\t`). Do not place tabs anywhere else.

Correct Format:
Output: COL title  VAL [title_1]; 	COL title  VAL [title_2];


✅ Use exactly one literal tab character — not multiple tabs, not "\\t" string.
❌ Never insert a tab between COL and VAL or inside values.
❌ Never output on multiple lines.



## EXAMPLES --only for context ----:
FEW-SHOT EXAMPLE BLOCKExample – Tripod system (match)  
Original →  
COL title VAL  "Manfrotto 504HD/546BK Tripod System"@en	COL title VAL  "Manfrotto 504HD-546BK Tripod System"@en  
Transformed →  
COL title VAL Manfrotto 504HD 546BK Tripod System;	COL title VAL Manfrotto 504HD 546BK Tripod System;

Example – Battery charger (match)  
Original →  
COL title VAL  "Single Battery Charging Cradle"@en	COL title VAL  "Zebra Single Battery Charger for ZQ110"@en  
Transformed →  
COL title VAL Zebra ZQ110 Single Battery Charging Cradle;	COL title VAL Zebra ZQ110 Single Battery Charger;

Example – Lens focal difference (non-match)  
Original →  
COL title VAL  "Canon EF 24-70mm f/4L IS USM Zoom Lens"@en	COL title VAL  "Canon EF 17-40mm f/4L USM"@en  
Transformed →  
COL title VAL Canon EF 24-70 mm f/4L IS USM Zoom Lens;	COL title VAL Canon EF 17-40 mm f/4L USM Lens;

Example  – Mirrorless body-only vs kit (non-match)
Original →  
COL title VAL  "Panasonic Lumix GH5 Mirrorless Camera Body Only (No Lens)"@en  DMC-GH5KBODY"@en	COL title VAL  "Panasonic Lumix GH5 12-60mm Kit (DMC-GH5M)"@en Bundle"@en  
Transformed →  
COL title VAL Panasonic Lumix GH5 Mirrorless Camera Body Only DMC-GH5KBODY;	COL title VAL Panasonic Lumix GH5 12-60 mm Kit DMC-GH5M;

Example  – Battery charger naming variant (match)  
Original →  
COL title VAL  "Nikon MH-25 Quick Charger for EN-EL15 Battery"@en	COL title VAL  "Nikon EN-EL15 Battery Charger MH-25"@en  
Transformed →  
COL title VAL Nikon MH-25 Charger for EN-EL15 Battery;	COL title VAL Nikon EN-EL15 Battery Charger MH-25;


---------------

## CRITICAL CONSTRAINTS:

- Maintain proper spacing throughout
- Only use tags specified in the rules

------------------------

Input: {s1}\t{s2}

PROVIDE ONLY THE CLEAN OUTPUTS SEPARATED BY **one literal tab character**, NOTHING ELSE. DO NOT PROVIDE EXTRA EXPLANATIONS.
Process each record pair according to these rules, maintaining structural integrity while highlighting key differences that affect matching accuracy. Your output should ONLY be the transformed records, with NO explanations.

"""



    
def extract_output_line_deepseek(text):
    """
    Extract the line that starts with 'Output:' and contains exactly one tab.
    If no valid line is found, raise an error.
    """
      
    for line in text.splitlines():
        if line.strip().startswith("Output:"):
            line = line.strip()

            # Attempt to fix if there's no real tab but just space between two records
            match = re.search(r'(COL .+?VAL .+?)( COL )', line)
            if match and line.count('\t') == 0:
                # Insert real tab between the two records
                parts = line[7:].split("COL ", 1)
                if len(parts) == 2:
                    fixed = f"Output: COL {parts[0].strip()}\tCOL {parts[1].strip()}"
                    return fixed

            # Otherwise, return as-is if it already has one real tab
            if line.count('\t') == 1:
                return line

    raise ValueError("❌ Could not find or fix a valid 'Output:' line with a tab in the model response.")


def clean_and_validate(result, s1, s2):
    result = result.strip()

    # Normalize any escaped \t
    result = result.replace("\\t", "\t")

    # If there's no real tab, force insert before the 2nd COL
    if result.count("\t") == 0:
        # Split into 2 parts at the second COL
        parts = result.split("COL ", 2)
        if len(parts) == 3:
            # Rebuild with a real tab
            result = parts[0].strip() + "COL " + parts[1].strip() + "\tCOL " + parts[2].strip()

    # Clean up multiple spaces/tabs
    result = re.sub(r"\s{2,}", " ", result)
    result = re.sub(r"\t+", "\t", result)

    # Final check
    tab_count = result.count("\t")
    if tab_count != 1:
        raise ValueError(
            f"❌ Output must contain exactly one real tab. Found {tab_count}: {repr(result)}"
        )

    parts = [p.strip() for p in result.split("\t") if p.strip()]
    if len(parts) != 2:
        raise ValueError(f"❌ Could not split into exactly 2 records: {repr(result)}")

    return result


def summarize_pair(s1, s2,label, max_tokens=128, max_attempts=5):
    
    # if label.strip() != "1":
    #     print("Skipping prompt: label is", label)
    #     return f"{s1}\t{s2}"
    
    cache_key = f"{s1}||{s2}"
    cache_path = get_cache_path(cache_key)

    if cache_path.exists():
        try:
            with open(cache_path, 'r') as f:
                cached_data = json.load(f)
                return cached_data['response']
        except:
            print(f"⚠️ Invalid cache file {cache_path}, will regenerate...")

    prompt = build_prompt(s1, s2,label, max_tokens)

    last_error = None
    for attempt in range(1, max_attempts + 1):
        try:
            response = ollama.chat(
                model="mistral-nemo:latest",
                options={"temperature": 0.0, "num_predict": 2000},
                 messages=[
                    {
                        "role": "system",
                        "content": (
                            "You are entity matcher for the ditto. Do not explain. "
                            "Do not describe anything. Do not say 'Output:' or '<think>'. "
                            "Do not provide reasoning, steps, formatting explanation, or notes. "
                            "Return EXACTLY one line with TWO transformed records separated by ONE real tab character. PRESERVE ORIGINAL CASE. Do NOT change to title case. Do not capitalize words unless already capitalized. "
                            "No headings. No thoughts. No multiple lines. No Markdown. No JSON. Only raw string output. "
                            "If you violate this, your output will be rejected."
                        )
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ]
            )

            result = response["message"]["content"].strip()
            # result = result.lower()
            # print("raw output:",result)
            # fresult = extract_output_line_deepseek(result)
            print("reslut **",result)
            
            result = clean_and_validate(result, s1, s2)

            with open(cache_path, 'w') as f:
                json.dump({"response": result}, f)

            print(f"✓ Valid output on attempt {attempt}")
            return result

        except Exception as e:
            print(f"❌ Attempt {attempt} failed: {e}")
            last_error = e

    print(f"❌ All {max_attempts} attempts failed. Returning original input.")
    return f"{s1}\t{s2}"


def preprocess_file(input_path):
    print(f"\n🔧 Preprocessing: {input_path}")
    input_path = Path(input_path)
    output_path = input_path.with_name(input_path.stem + "_enrich.txt")

    cache = {}

    with open(input_path, "r", encoding="utf-8") as fin, open(output_path, "w", encoding="utf-8") as fout:
        for i, line in enumerate(fin, 1):
            try:
                parts = line.strip().split('\t')
                if len(parts) != 3:
                    raise ValueError(f"Expected 3 fields, got {len(parts)}")

                s1, s2, label = parts
                cache_key = f"{s1}||{s2}"
            
                if cache_key not in cache:
                    cache[cache_key] = summarize_pair(s1, s2,label)
                    print(f"✓ Line {i} summarized.")

                transformed = cache[cache_key]
                formatted = f"{transformed}\t{label}\n"

                if formatted.strip().count('\t') != 2:
                    raise ValueError(f"❌ Final formatted line is malformed: {repr(formatted)}")

                fout.write(formatted)

            except Exception as e:
                print(f"❌ Skipping line {i} due to error: {e}")

    print(f"✅ Saved enriched file to: {output_path}")


if __name__ == "__main__":
    filenames = [ "test.txt","valid.txt","train.txt"]

    for fname in filenames:
        path = Path(fname)
        if not path.exists():
            print(f"⚠️ File not found: {fname}")
            continue

        preprocess_file(str(path))

